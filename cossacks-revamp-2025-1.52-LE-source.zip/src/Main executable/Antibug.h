void ADDSUMM(void* lp,int n);
void GETALL();
void CHKALL();