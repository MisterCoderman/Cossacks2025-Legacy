bool CreateMultiplaterInterface();
void InitMultiDialogs();
void SetupMultiplayer(HINSTANCE hInstance);
void ShutdownMultiplayer(bool Final);