void InitDANGER();
void CheckDOBJS();
byte GetDangValue(int x,int y);